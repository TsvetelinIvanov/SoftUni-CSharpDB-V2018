﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.App
{
    public class CardealerProfile : Profile
    {
        public CardealerProfile()
        {

        }
    }
}
