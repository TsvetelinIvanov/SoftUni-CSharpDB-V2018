﻿using System;

namespace CarDealer.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-UGR754R\SQLEXPRESS;" +
                                              @"Database=CarDealer;" +
                                              @"Integrated Security=true";
    }
}
