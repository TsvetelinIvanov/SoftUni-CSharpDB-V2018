﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamBuilder.Models.Enums
{
    public enum GenderEnum
    {
        Male,
        Female
    }
}
