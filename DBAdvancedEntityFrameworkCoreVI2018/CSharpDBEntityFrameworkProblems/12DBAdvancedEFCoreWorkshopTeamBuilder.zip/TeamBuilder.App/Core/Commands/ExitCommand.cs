﻿using System;
using System.Collections.Generic;
using System.Text;
using TeamBuilder.App.Utilities;

namespace TeamBuilder.App.Core.Commands
{
    public class ExitCommand : ICommand
    {
        public string Execute(string[] args)
        {
            Check.CheckLength(0, args);
            Environment.Exit(0);
            return "Bye!";
        }
    }
}
