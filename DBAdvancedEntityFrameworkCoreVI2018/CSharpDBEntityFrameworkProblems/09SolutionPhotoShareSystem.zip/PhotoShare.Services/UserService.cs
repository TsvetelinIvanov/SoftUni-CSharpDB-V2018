﻿using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using PhotoShare.Data;
using PhotoShare.Models;
using PhotoShare.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PhotoShare.Services
{
    public class UserService : IUserService
    {
        private readonly PhotoShareContext context;

        public UserService(PhotoShareContext context)
        {
            this.context = context;
        }

        public TModel ById<TModel>(int id)
                => this.By<TModel>(i => i.Id == id).SingleOrDefault();

        public TModel ByUsername<TModel>(string username)
                => this.By<TModel>(i => i.Username == username).SingleOrDefault();

        public void ChangePassword(int userId, string password)
        {
            var user = this.ById<User>(userId);
            user.Password = password;
            this.context.SaveChanges();
        }
        public void Delete(string username)
        {
            var user = context.Users.FirstOrDefault(x => x.Username == username);
            user.IsDeleted = true;
            this.context.SaveChanges();
        }

        public bool IsDeleted(string username)
        { 
            var user= this.ByUsername<User>(username);
            if (user.IsDeleted == true)
            {
                return true;
            }
            else return false;
        }

        //public int FriendsCount(string username)
        //{
        //    var count = context.Users
        //        .FirstOrDefault(x => x.Username == username)
        //        .Include(x=>x.FriendsAdded)
        //        .Count;
        //    return count;
        //}

        public bool Exists(int id)
                => this.ById<User>(id) != null;

        public bool Exists(string name)
                => this.ByUsername<User>(name) != null;

        public User Register(string username, string password, string email)
        {
            var user = new User
            {
                Username = username,
                Password = password,
                Email = email,
                IsDeleted=false
            };
            this.context.Users.Add(user);
            this.context.SaveChanges();
            return user;
        }

        public void SetBornTown(int userId, int townId)
        {
            var user = this.ById<User>(userId);
            user.BornTownId = townId;
            this.context.SaveChanges();
        }

        public void SetCurrentTown(int userId, int townId)
        {
            var user = this.ById<User>(userId);
            user.CurrentTownId = townId;
            this.context.SaveChanges();
        }

        public Friendship AcceptFriend(int userId, int friendId)
        {
            var friendship = new Friendship
            {
                UserId = userId,
                FriendId = friendId
            };

            this.context.Friendships.Add(friendship);
            this.context.SaveChanges();
            return friendship;
        }

        public Friendship AddFriend(int userId, int friendId)
        {
            FriendsReverseSide(userId, friendId);

            var friendship = new Friendship
            {
                UserId = userId,
                FriendId = friendId
            };

            this.context.Friendships.Add(friendship);
            this.context.SaveChanges();
            return friendship;
        }

        public bool IfHaveFriendship(int userId,int friendId)
        {
            return this.context.Friendships.Any(x => x.UserId == userId && x.FriendId == friendId);
        }

        private void FriendsReverseSide(int userId,int friendId)
        {
            var friendship = new Friendship
            {
                UserId = friendId,
                FriendId = userId
            };
            this.context.Friendships.Add(friendship);
            context.SaveChanges();
        }

        private IEnumerable<TModel> By<TModel>(Func<User, bool> predicate)
               => this.context.Users.Include(x=>x.FriendsAdded).Where(predicate)
                   .AsQueryable().ProjectTo<TModel>();

        public bool UserExists(string username)
        {
            return this.context.Users.Any(x => x.Username == username);
        }

        public bool CheckPassword(string username, string password)
        {
            bool exists = this.UserExists(username);
            return this.context.Users.FirstOrDefault(x=>x.Username==username).Password==password;

        }

        public TModel ByUsernameAndPassword<TModel>(string username, string password) => By<TModel>(x => x.Username == username && x.Password == password).SingleOrDefault();
        
    }
        
}