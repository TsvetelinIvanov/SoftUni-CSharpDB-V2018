﻿using PhotoShare.Data;
using PhotoShare.Models;
using PhotoShare.Services.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhotoShare.Services
{
    public class UserSessionService : IUserSessionService
    {
        private readonly IUserService userService;
        //private readonly PhotoShareContext context;
        private bool hasLoggedInUser = false;

        public UserSessionService(IUserService userService)
        {
            this.userService = userService;
        }

        //public void Login(string username, string password)
        //{
        //    hasLoggedInUser = this.userService.CheckPassword(username,password);

        //    if(!hasLoggedInUser)
        //    {
        //        throw new ArgumentException("Invalid username or password!");
        //    }
        //}
        //public void Logout()
        //{   this.hasLoggedInUser = false;    }
        // public bool HasLoggedInUser()
        //{   return this.hasLoggedInUser; }

        public User User { get; private set; }

        public bool IsLoggedIn() => this.User != null;

        public User Login (string username,string password)
        {
            this.User = userService.ByUsernameAndPassword<User>(username, password);
            return this.User;
        }

        public void Logout() => this.User = null;
        
        
    }
}
