﻿using PhotoShare.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace PhotoShare.Services.Contracts
{
     public interface IUserSessionService
    {
        User User { get; }

        User Login(string username, string password);

        void Logout();
        // bool HasLoggedInUser();

        bool IsLoggedIn();
    }
}
