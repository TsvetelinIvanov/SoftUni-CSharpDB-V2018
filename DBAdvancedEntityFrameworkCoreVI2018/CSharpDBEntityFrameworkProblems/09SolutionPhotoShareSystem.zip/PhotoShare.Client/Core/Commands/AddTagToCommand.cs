﻿namespace PhotoShare.Client.Core.Commands
{
    using System;
    using Contracts;
    using PhotoShare.Client.Core.Dtos;
    using PhotoShare.Client.Utilities;
    using PhotoShare.Services.Contracts;

    public class AddTagToCommand : ICommand
    {
        private readonly IAlbumService albumService;
        private readonly ITagService tagService;
        private readonly IAlbumTagService albumTagService;
        private readonly IUserSessionService userSessionService;

        public AddTagToCommand(Services.Contracts.IAlbumTagService albumTagService,
            IAlbumService albumService,ITagService tagService,IUserSessionService userSessionService)
        {
            this.albumTagService = albumTagService;
            this.tagService = tagService;
            this.albumService = albumService;
            this.userSessionService = userSessionService;
        }

        // AddTagTo <albumName> <tag>
        public string Execute(string[] args)
        {
            string albumTitle = args[0];
            string tagName = args[1];
            tagName = tagName.ValidateOrTransform();

            var albumExists = this.albumService.Exists(albumTitle);
            var tagExists = this.tagService.Exists(tagName);

            if (!userSessionService.IsLoggedIn())
            {
                throw new InvalidOperationException("Invalid credentials!");
            }

            if (!albumExists || !tagExists)
            {
                throw new ArgumentException("Either tag or album do not exist!");
            }

            
            var albumId = this.albumService.ByName<AlbumDto>(albumTitle).Id;
            int tagId = this.tagService.ByName<TagDto>(tagName).Id;

            var tagToAlbum = this.albumTagService.AddTagTo(albumId, tagId);
            return $"Tag {tagName} added to {albumTitle}!";
        }
    }
}
