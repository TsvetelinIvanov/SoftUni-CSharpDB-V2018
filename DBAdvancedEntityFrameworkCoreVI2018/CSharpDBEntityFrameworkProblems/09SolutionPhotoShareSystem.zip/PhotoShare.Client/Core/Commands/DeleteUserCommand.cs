﻿namespace PhotoShare.Client.Core.Commands
{
    using System;

    using Dtos;
    using Contracts;
    using Services.Contracts;
    using PhotoShare.Models;

    public class DeleteUserCommand : ICommand
    {
        private readonly IUserService userService;
        private readonly IUserSessionService userSessionService;

        public DeleteUserCommand(IUserService userService,IUserSessionService userSessionService)
        {
            this.userService = userService;
            this.userSessionService = userSessionService;
        }

        // DeleteUser <username>
        public string Execute(string[] data)
        {
            string username = data[0];

            if (!userSessionService.IsLoggedIn() || this.userSessionService.User.Username != username)
            {
                throw new InvalidOperationException("Invalid credentials!");
            }

            var userExists = this.userService.Exists(username);

            var userIsDeleted = this.userService.IsDeleted(username);

            if (!userExists)
            {
                throw new ArgumentException($"User {username} not found!");
            }

            else if(userIsDeleted)
            {
                throw new InvalidOperationException($"User {username} is already deleted!");
            }

            else
            this.userService.Delete(username);


            return $"User {username} was deleted succesfully!";
        }
    }
}
