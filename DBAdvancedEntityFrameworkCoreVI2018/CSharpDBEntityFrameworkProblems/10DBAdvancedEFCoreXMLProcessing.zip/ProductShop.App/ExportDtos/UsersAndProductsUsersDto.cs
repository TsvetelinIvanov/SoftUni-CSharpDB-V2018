﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ProductShop.App.ExportDtos
{
    [XmlRoot("users")]
    public class UsersAndProductsUsersDto
    {
        [XmlAttribute("count")]
        public int Count { get; set; }

        [XmlElement("user")]
        public UsersAndProductsUserDto[] UsersAndProductsUserDtos { get; set; }
    }
}

