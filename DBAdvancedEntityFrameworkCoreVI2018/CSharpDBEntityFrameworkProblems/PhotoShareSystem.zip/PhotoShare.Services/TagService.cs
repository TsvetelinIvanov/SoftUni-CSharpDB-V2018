﻿namespace PhotoShare.Services
{
    public class TagService
    {
    }
}
