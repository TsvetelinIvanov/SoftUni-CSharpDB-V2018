﻿namespace PhotoShare.Services
{
	public class AlbumService
    {

    }
}
